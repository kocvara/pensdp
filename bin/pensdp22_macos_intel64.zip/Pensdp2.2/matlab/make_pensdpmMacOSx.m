%**************************************************************************
%                mex-command PENSDP 2.2 (Matlab interface)                *
%								                                          *
% Copyright (c) 2003-2011 by M. Kocvara and M. Stingl                     *
% Version 03/02/11                                                        *
%**************************************************************************

function make_pensdpmw64()

mex -O -v -largeArrayDims pensdpm.c penoutm.c -L../lib  -lpensdp -lmwlapack -lmwblas -lgfortran_mac
