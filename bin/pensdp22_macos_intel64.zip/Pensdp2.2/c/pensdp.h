#ifndef PENSDP_H
#define PENSDP_H

/* ----------------------------------------
pensdp.h. TO BE INCLUDED BY PENSDP DRIVER
---------------------------------------- */

#define INTEGER(x) (int *)malloc((x)*sizeof(int))
#define DOUBLE(x) (double *)malloc((x)*sizeof(double))

#ifdef __cplusplus
extern "C" {
#endif    

int pensdp(int vars, int constr, int mconstr, int* msizes, double* fX,  
        double* x0, double* u0, double *uoutput, double* fobj, double* ci,
        int* bi_dim, int* bi_idx, double* bi_val, 
        int* ai_dim, int* ai_idx, int* ai_nzs,
        double* ai_val, int* ai_col, int* ai_row,
        int* ioptions, double* foptions,
        int* iresults, double* fresults, int* inform);

#ifdef __cplusplus
}
#endif    

#endif
