/******************************************************/
/* driver_sdp_c.c : 'C' driver for PENSDP             */
/*                                                    */
/* Copyright (c) 2005 by M. Kocvara and M. Stingl     */
/* Version 10/10/05                                   */
/******************************************************/

#include "pensdp.h"
#include <stdlib.h>

int main() {

  /* basic problem dimensions */
  int vars = 0, constr = 0, mconstr = 0;
  int luoutput = 0, lbi = 0, lai = 0, nzsai = 0; 
  
  /* error flag */
  int inform = 0; 
  
  /* function value */
  double fX = 0.;
  
  /* array reserved for block sizes of matrix constraints */
  int *msizes = 0;
  
  /* array reserved for initial iterate (input) 
     and optimal primal variables (output) */
  double *x0 = 0;
  
  /* array reserved for initial (factors for) dual variables (input) */
  double *u0 = 0;

  /* array reserved for optimal dual variables (output) */
  double *uoutput = 0;
  
  /* objective */
  double *fobj = 0;

  /* rhs of linear constraints */
  double *ci = 0;
  
  /* arrays for linear constraints */
  int *bi_dim = 0, *bi_idx = 0;
  double *bi_val = 0;
  
  /* arrays for matrix constraints */
  int *ai_dim = 0, *ai_idx = 0, *ai_nzs = 0, *ai_col = 0, *ai_row = 0;
  double *ai_val = 0;
  
  /* arrays reserved for results */ 
  int iresults[4] = {0,0,0,0};
  double fresults[5] = {0.0,0.0,0.0,0.0,0.0};

  /* default options */
  int ioptions[15] = {1,50,100,2,0,1,0,0,0,0,0,0,0,1,1}; 
  double foptions[12] = {1.0,0.7,0.1,1.0E-7,1.0E-6,1.0E-14,1.0E-2,1.0e-1,0.0e0,1.0,1.0e-6,5.0e-2};

  /* Set up problem dimensions */
  
  vars    =  3;
  constr  =  4;
  mconstr =  1;
  luoutput    = 10;
  lbi    =  4;
  lai   =  4;
  nzsai   = 16;

  /* allocate memory */
  
  msizes = INTEGER (mconstr);
  
  x0 = DOUBLE(vars);
  uoutput = DOUBLE(luoutput);
  fobj = DOUBLE(vars);

  if(constr) {
    ci = DOUBLE(constr);
    bi_dim = INTEGER(constr);
    bi_idx = INTEGER(lbi);
    bi_val = DOUBLE(lbi);
  }

  if(mconstr) {
    ai_dim = INTEGER(mconstr);
    ai_idx = INTEGER(lai);
    ai_nzs = INTEGER(lai);
    ai_col = INTEGER(nzsai);
    ai_row = INTEGER(nzsai);
    ai_val = DOUBLE(nzsai);
  }

  /* assign values to input structures */
  
  msizes[0] = 3;

  x0[0] = 0.0;
  x0[1] = 0.0;
  x0[2] = 0.0;

  fobj[0] = 0.0;
  fobj[1] = 0.0;
  fobj[2] = 1.0;

  ci[0] = 0.5;
  ci[1] = 2.0;
  ci[2] = 3.0;
  ci[3] = 7.0;

  bi_dim[0] = 1;
  bi_dim[1] = 1;
  bi_dim[2] = 1;
  bi_dim[3] = 1;

  bi_idx[0] = 0;
  bi_idx[1] = 0;
  bi_idx[2] = 1;
  bi_idx[3] = 1;

  bi_val[0] = -1.0;
  bi_val[1] =  1.0;
  bi_val[2] = -1.0;
  bi_val[3] =  1.0;

  ai_dim[0] = 4;

  ai_idx[0] = 0;
  ai_idx[1] = 1;
  ai_idx[2] = 2;
  ai_idx[3] = 3;

  ai_nzs[0] = 4;
  ai_nzs[1] = 4;
  ai_nzs[2] = 5;
  ai_nzs[3] = 3;

  ai_col[0]  = 0;
  ai_col[1]  = 1;
  ai_col[2]  = 2;
  ai_col[3]  = 1;
  ai_col[4]  = 0;
  ai_col[5]  = 1;
  ai_col[6]  = 2;
  ai_col[7]  = 2;
  ai_col[8]  = 0;
  ai_col[9]  = 1;
  ai_col[10] = 2;
  ai_col[11] = 1;
  ai_col[12] = 2;
  ai_col[13] = 0;
  ai_col[14] = 1;
  ai_col[15] = 2;

  ai_row[0]  = 0;
  ai_row[1]  = 0;
  ai_row[2]  = 0;
  ai_row[3]  = 1;
  ai_row[4]  = 0;
  ai_row[5]  = 0;
  ai_row[6]  = 1;
  ai_row[7]  = 2;
  ai_row[8]  = 0;
  ai_row[9]  = 0;
  ai_row[10] = 0;
  ai_row[11] = 1;
  ai_row[12] = 1;
  ai_row[13] = 0;
  ai_row[14] = 1;
  ai_row[15] = 2;

  ai_val[0]  = -10.0;
  ai_val[1]  = -0.5;
  ai_val[2]  = -2.0;
  ai_val[3]  =  4.5;
  ai_val[4]  =  9.0;
  ai_val[5]  =  0.5;
  ai_val[6]  = -3.0;
  ai_val[7]  = -1.0;
  ai_val[8]  = -1.8;
  ai_val[9]  = -0.1;
  ai_val[10] = -0.4;
  ai_val[11] =  1.2;
  ai_val[12] = -1.0;
  ai_val[13] = -1.0;
  ai_val[14] = -1.0;
  ai_val[15] = -1.0;

  /* Call pensdp */
  pensdp(vars, constr, mconstr, msizes,
    &fX, x0, u0, uoutput, fobj, ci,
    bi_dim, bi_idx, bi_val,
    ai_dim, ai_idx, ai_nzs,
    ai_val, ai_col, ai_row,
    ioptions, foptions,
    iresults, fresults, &inform);
  

  /* free memory */
  if(msizes)
    free(msizes);
  if(x0)
    free(x0);
  if(uoutput)
    free(uoutput);
  if(fobj)
    free(fobj);
  if(ci)
    free(ci);
  if(bi_dim)
    free(bi_dim);
  if(bi_idx)
    free(bi_idx);
  if(bi_val)
    free(bi_val);
  if(ai_dim)
    free(ai_dim);
  if(ai_idx)
    free(ai_idx);
  if(ai_nzs)
    free(ai_nzs);
  if(ai_col)
    free(ai_col);
  if(ai_row)
    free(ai_row);
  if(ai_val)
    free(ai_val);
  
  return inform;
}
/* END */


