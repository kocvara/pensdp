/******************************************************/
/* penoutm.c : sample file for output generation      */
/*             in matlab                              */
/*                                                    */
/* Copyright (c) 2003 by M. Kocvara and M. Stingl     */
/* Version 30/10/03                                   */
/******************************************************/

#include <stdio.h>
#include "mex.h"

void penout(char* stream) {
  mexPrintf(stream);
  mexEvalString("pause(.001);");
}

void penerr(char* stream) {
  mexPrintf(stream);
  mexEvalString("pause(.001);");
}

int uout(double *u, int nUlen, double** umat, 
         int nNumUmats, int* nUmatSizes, int* bSymmetric) {
  int i, j, k, dim;	
  FILE* fp;
  
  if ((fp = fopen("u.dat", "w")) == NULL)
  {
    return 0;
  } 
  
  for(i = 0; i < nUlen; i++) 
    fprintf(fp, "%4d %18.7E\n", i+1, u[i]);
  
  if(nUlen)
    fprintf(fp, "\n");

  for(i=0; i<nNumUmats; i++) {    
    dim = nUmatSizes[i];
    for(j=0; j<dim; j++) 
      for(k=0; k<dim; k++)
      {
        if(!bSymmetric[i])
          fprintf(fp, "%4d %4d %18.7E\n", j+1, k+1, umat[i][j*dim+k]);
        else {
          if (j<k)
            fprintf(fp, "%4d %4d %18.7E\n", j+1, k+1, umat[i][k*(k+1)/2+j]);
          else
            fprintf(fp, "%4d %4d %18.7E\n", j+1, k+1, umat[i][j*(j+1)/2+k]);
        }
      }
    fprintf(fp, "\n"); 
  }	
  
  fclose (fp);
  

  return 1;
}

int xout(double *x, int xlen) {
  int i;	
  FILE* fp;
  
  if ((fp = fopen("x.dat", "w")) == NULL)
  {
    return 0;
  } 
  
  for(i = 0; i < xlen; i++) 
    fprintf(fp, "%4d %18.7E\n", i+1, x[i]);
  
  fclose (fp);
  
  return 1;
}

