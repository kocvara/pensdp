%**************************************************************************
%                mex-command PENSDP 2.2 (Matlab interface)                *
%		                                                          *
% Copyright (c) 2010 by M. Kocvara and M. Stingl                          *
% Version 30/10/10                                                        *
%**************************************************************************

function make_pensdpm()

    mex -O -v -largeArrayDims pensdpm.c penoutm.c -L../lib -lpensdp -lmwlapack -lmwblas

