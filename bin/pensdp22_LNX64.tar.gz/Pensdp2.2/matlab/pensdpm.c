/******************************************************/
/* MEX FILE INTERFACE FOR PENSDP                      */
/*                                                    */
/* Copyright (c) 2018 by M. Kocvara and M. Stingl     */
/* Version 04/02/18                                   */
/******************************************************/

#include "mex.h"
/* BEGIN */
void determine_class(mxArray  *array_ptr)
{
  mxClassID  category;
  category = mxGetClassID(array_ptr);
}

int pensdp(int vars, int constr, int mconstr, int* msizes, double* fX,  
        double* x0, double* u0, double *uoutput, double* fobj, double* ci,
        int* bi_dim, int* bi_idx, double* bi_val, 
        int* ai_dim, int* ai_idx, int* ai_nzs,
        double* ai_val, int* ai_col, int* ai_row,
        int* ioptions, double* foptions,
        int* iresults, double* fresults, int* inform);

void
mexFunction(int nlhs,mxArray *plhs[],int nrhs,const mxArray *prhs[])
{
    mxArray   *array_ptr = 0, *field_ptr = 0;
    int        c, cc, dim;
    double     *pr = 0;
    
    int    total_num_of_elements = 0, i, inform = 0;
    double fX = 0, *real_data_ptr = 0;
    int    vars = 0, constr = 0, *bi_dim = 0, *bi_idx = 0;
    int    mconstr = 0, *ai_dim = 0, *msizes = 0, *ai_col = 0, *ai_row = 0, *ai_idx = 0, *ai_nzs = 0;
    int    *ioptions = 0, *iresults = 0;
    double *fobj = 0, *ci = 0, *bi_val = 0, *ai_val = 0, *foptions = 0, *x_opt = 0, *u0 = 0, *uoutput = 0;
    double *fresults = 0;
    
    mwIndex     *ir, *jc;
    mwSize      number_of_nonzeros;
    int      total=0;

  if(nrhs < 1) {
    mexPrintf("Please call pennon with problem data as right hand side argument.\n");
    return;
  }

  /* Examine input (right-hand-side) arguments. */
  array_ptr = (mxArray *)prhs[0];
  determine_class(array_ptr);
  
  /* vars */    
  field_ptr = mxGetField(array_ptr, 0, "vars");

  if(!field_ptr) {
    mexPrintf("Error in input structure: 'vars' is missing.\n");
    return;
  }

  real_data_ptr = (double *)mxGetPr(field_ptr);
  
  total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
  
  vars = (int) real_data_ptr[0];
  
  /* fobj */ 
  field_ptr = mxGetField(array_ptr, 0, "fobj");
  if(!field_ptr) {      
    mexPrintf("Error in input structure: 'fobj' is missing.\n");
    return;
  }

  /* sparse fobj */
  if (mxIsSparse(field_ptr))  {
      
      total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
      number_of_nonzeros = mxGetNzmax(field_ptr);
      ir = (int *)mxGetIr(field_ptr);
      jc = (int *)mxGetJc(field_ptr);
      pr = (double *)mxGetPr(field_ptr);
   
      /* mexPrintf("%d \n", total_num_of_elements);
      mexPrintf("%d \n", number_of_nonzeros);
      
      for (c=0; c<number_of_nonzeros; c++)  {
          mexPrintf("%d %d %d %g\n", c, ir[c+1], jc[c+1], pr[c]);
      } */

      fobj = mxCalloc(total_num_of_elements, sizeof(double));
      
      for (c=0; c<total_num_of_elements; c++)  {
          fobj[c] = 0.0;
      }
      
      if(mxGetM(field_ptr) > mxGetN(field_ptr)){
          for (c=0; c<number_of_nonzeros; c++)
              fobj[ir[c]] = pr[c];
      }
      if(mxGetM(field_ptr) <= mxGetN(field_ptr)){
          for (c=0; c<mxGetN(field_ptr); c++){
              if(jc[c]==jc[c+1])
                  continue;
              else
                  fobj[c] = pr[total++];
          }
      }
           
      /* for (c=0; c<total_num_of_elements; c++)  {
          mexPrintf("%d  %g\n", c,fobj[c]);
      } */

  }
 
    /*    mexPrintf("Error in 'pen' input structure: 'fobj' must not be sparse.\n"); 
    return;} */
  
  /* dense fobj */
  if (!mxIsSparse(field_ptr))  {
      real_data_ptr = (double *)mxGetPr(field_ptr);
      
      total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
      
      fobj = mxCalloc(total_num_of_elements, sizeof(double));
      for (c = 0; c < total_num_of_elements; c++)
          fobj[c] = real_data_ptr[c];
  }
      
  /* constr */
  field_ptr = mxGetField(array_ptr, 0, "constr");
  if(!field_ptr) {
      mexPrintf("Error in input structure: 'constr' is missing.\n");
      return;
  }
  
  real_data_ptr = (double *)mxGetPr(field_ptr);
  
  total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
  
  constr = (int) real_data_ptr[0];
  
  
  /* ci */ 
  if(constr) {
    field_ptr = mxGetField(array_ptr, 0, "ci");
    if(!field_ptr) {
      mexPrintf("Error in input structure: 'ci' is missing.\n");
      return;
    }
    real_data_ptr = (double *)mxGetPr(field_ptr);
    
    total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
    
    ci = mxCalloc(total_num_of_elements, sizeof(double));
    for (c = 0; c < total_num_of_elements; c++)
      ci[c] = real_data_ptr[c];
    
    /*mexPrintf("ci: %g\n", ci[0]);*/
    
    /* bi_dim */ 
    field_ptr = mxGetField(array_ptr, 0, "bi_dim");
    if(!field_ptr) {
      mexPrintf("Error in input structure: 'bi_dim' is missing.\n");
      return;
    }

    real_data_ptr = (double *)mxGetPr(field_ptr);
    
    total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
    
    bi_dim = mxCalloc(total_num_of_elements, sizeof(int));
    for (c = 0; c < total_num_of_elements; c++)
      bi_dim[c] = (int) real_data_ptr[c];
    
    /*mexPrintf("bi_dim: %d\n", bi_dim[0]);*/
    
    /* bi_idx */ 
    field_ptr = mxGetField(array_ptr, 0, "bi_idx");
    if(!field_ptr) {
      mexPrintf("Error in input structure: 'bi_idx' is missing.\n");
      return;
    }

    real_data_ptr = (double *)mxGetPr(field_ptr);
    
    total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
    
    bi_idx = mxCalloc(total_num_of_elements, sizeof(int));
    for (c = 0; c < total_num_of_elements; c++)
      bi_idx[c] = (int) real_data_ptr[c];
    
    /*mexPrintf("bi_idx: %d\n", bi_idx[0]);*/
    
    /* bi_val */ 
    field_ptr = mxGetField(array_ptr, 0, "bi_val");
    if(!field_ptr) {
      mexPrintf("Error in input structure: 'bi_val' is missing.\n");
      return;
    }

    real_data_ptr = (double *)mxGetPr(field_ptr);
    
    total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
    
    bi_val = mxCalloc(total_num_of_elements, sizeof(double));
    for (c = 0; c < total_num_of_elements; c++)
      bi_val[c] = real_data_ptr[c];
    
    /*mexPrIntf("bi_val: %g\n", bi_val[0]);*/
  }
  
  /* mconstr */    
  field_ptr = mxGetField(array_ptr, 0, "mconstr");
  if(!field_ptr) {
    mexPrintf("Error in input structure: 'mconstr' is missing.\n");
    return;
  }

  real_data_ptr = (double *)mxGetPr(field_ptr);
  
  total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
  
  mconstr = (int) real_data_ptr[0];
  
  
  if(mconstr) {   
      /* msizes */ 
      field_ptr = mxGetField(array_ptr, 0, "msizes");
      if(!field_ptr) {
        mexPrintf("Error in input structure: 'msizes' is missing.\n");
        return;
      }

      real_data_ptr = (double *)mxGetPr(field_ptr);
      
      total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
      
      msizes = mxCalloc(total_num_of_elements, sizeof(int));
      for (c = 0; c < total_num_of_elements; c++)
        msizes[c] = (int) real_data_ptr[c];
      
      /*mexPrintf("msizes: %d\n", msizes[0]);*/
      
    /* ai_dim */ 
    field_ptr = mxGetField(array_ptr, 0, "ai_dim");
    if(!field_ptr) {
      mexPrintf("Error in input structure: 'ai_dim' is missing.\n");
      return;
    }

    real_data_ptr = (double *)mxGetPr(field_ptr);
    
    total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
    
    for (c = 0; c < total_num_of_elements; c++) {
      if( real_data_ptr[c] != 0)
        break;
    }
    
    if(c >= total_num_of_elements) {
      ai_dim = mxCalloc(mconstr, sizeof(int));
      for (c = 0; c < mconstr; c++)
        ai_dim[c] = 0;      
      ai_col = mxCalloc(1, sizeof(int));
      ai_row = mxCalloc(1, sizeof(int));
      ai_val = mxCalloc(1, sizeof(double));
      ai_idx = mxCalloc(1, sizeof(int));
      ai_nzs = mxCalloc(1, sizeof(int));      
    }
    
    else {
      ai_dim = mxCalloc(total_num_of_elements, sizeof(int));
      for (c = 0; c < total_num_of_elements; c++)
        ai_dim[c] = (int) real_data_ptr[c];
      
      /* mexPrintf("ai_dim: %d\n", ai_dim[0]);*/
      
      /* ai_col */ 
      field_ptr = mxGetField(array_ptr, 0, "ai_col");
      if(!field_ptr) {
        mexPrintf("Error in input structure: 'ai_col' is missing.\n");
        return;
      }
      real_data_ptr = (double *)mxGetPr(field_ptr);
      
      total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
      
      ai_col = mxCalloc(total_num_of_elements, sizeof(int));
      for (c = 0; c < total_num_of_elements; c++)
        ai_col[c] = (int) real_data_ptr[c];
      
      /* mexPrintf("ai_col: %d\n", ai_col[0]);*/
      
      /* ai_row */ 
      field_ptr = mxGetField(array_ptr, 0, "ai_row");
      if(!field_ptr) {
        mexPrintf("Error in input structure: 'ai_row' is missing.\n");
        return;
      }
      real_data_ptr = (double *)mxGetPr(field_ptr);
      
      total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
      
      ai_row = mxCalloc(total_num_of_elements, sizeof(int));
      for (c = 0; c < total_num_of_elements; c++)
        ai_row[c] = (int) real_data_ptr[c];
      
      /* ai_val */ 
      field_ptr = mxGetField(array_ptr, 0, "ai_val");
      if(!field_ptr) {
        mexPrintf("Error in input structure: 'ai_val' is missing.\n");
        return;
      }
      real_data_ptr = (double *)mxGetPr(field_ptr);
      
      total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
      
      ai_val = mxCalloc(total_num_of_elements, sizeof(double));
      for (c = 0; c < total_num_of_elements; c++)
        ai_val[c] = real_data_ptr[c];
      
      /* ai_idx */ 
      field_ptr = mxGetField(array_ptr, 0, "ai_idx");
      if(!field_ptr) {
        mexPrintf("Error in input structure: 'ai_idx' is missing.\n");
        return;
      }
      real_data_ptr = (double *)mxGetPr(field_ptr);
      
      total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
      
      ai_idx = mxCalloc(total_num_of_elements, sizeof(int));
      for (c = 0; c < total_num_of_elements; c++)
        ai_idx[c] = (int) real_data_ptr[c];
      
      /* ai_nzs */ 
      field_ptr = mxGetField(array_ptr, 0, "ai_nzs");
      if(!field_ptr) {
        mexPrintf("Error in input structure: 'ai_nzs' is missing.\n");
        return;
      }
      real_data_ptr = (double *)mxGetPr(field_ptr);
      
      total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
      
      ai_nzs = mxCalloc(total_num_of_elements, sizeof(int));
      for (c = 0; c < total_num_of_elements; c++)
        ai_nzs[c] = (int) real_data_ptr[c];
    } 
  }

  else {
    ai_dim = mxCalloc(1, sizeof(int));
    msizes = mxCalloc(1, sizeof(int));
    ai_col = mxCalloc(1, sizeof(int));
    ai_row = mxCalloc(1, sizeof(int));
    ai_val = mxCalloc(1, sizeof(double));
    ai_idx = mxCalloc(1, sizeof(int));
    ai_nzs = mxCalloc(1, sizeof(int));
  }
  
  /* ioptions */ 
  field_ptr = mxGetField(array_ptr, 0, "ioptions");
  if(!field_ptr) {
    mexPrintf("Error in input structure: 'ioptions' is missing.\n");
    return;
  }

  real_data_ptr = (double *)mxGetPr(field_ptr);
  
  total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
  
  ioptions = mxCalloc(15, sizeof(int));
  for (c = 0; c < total_num_of_elements; c++)
    ioptions[c] = (int) real_data_ptr[c];
    
  if(total_num_of_elements < 9)
    ioptions[8] = 0;
  if(total_num_of_elements < 10)
    ioptions[9] = 0;
  if(total_num_of_elements < 11)
    ioptions[10] = 0;
  if(total_num_of_elements < 12)
    ioptions[11] = 0;
  if(total_num_of_elements < 13)
    ioptions[12] = 0;
  if(total_num_of_elements < 14)
    ioptions[13] = 1;
  if(total_num_of_elements < 15)
    ioptions[14] = 1;

  /* foptions */ 
  field_ptr = mxGetField(array_ptr, 0, "foptions");
  if(!field_ptr) {
    mexPrintf("Error in input structure: 'foptions' is missing.\n");
    return;
  }
  real_data_ptr = (double *)mxGetPr(field_ptr);
  
  total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
  
  if (total_num_of_elements > 0)
  {
    foptions = mxCalloc(12, sizeof(double));
    for (c = 0; c < total_num_of_elements; c++)
      foptions[c] = real_data_ptr[c];
    
    if(total_num_of_elements < 8)
      foptions[7] = 1.0;
    if(total_num_of_elements < 9)
      foptions[8] = 0.2;
    if(total_num_of_elements < 10)
      foptions[9] = 1.0;
    if(total_num_of_elements < 11)
      foptions[10] = 1.0e-6;
    if(total_num_of_elements < 12)
      foptions[11] = 5.0e-2;
  }
  
  if(nlhs > 1) {
    plhs[1] = mxCreateDoubleMatrix(1, vars, mxREAL);
    x_opt = (double *)mxGetPr(plhs[1]);
  }
  
  else {
    x_opt = mxCalloc(vars, sizeof(double));
  }
  
  /* x0 */ 
  field_ptr = mxGetField(array_ptr, 0, "x0");
  if(!field_ptr) {
    mexPrintf("Error in input structure: 'x0' is missing.\n");
    return;
  }
  real_data_ptr = (double *)mxGetPr(field_ptr);
  
  total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
  
  for (c = 0; c < total_num_of_elements; c++)
    x_opt[c] = real_data_ptr[c];
  
  /* u0 */ 
  field_ptr = mxGetField(array_ptr, 0, "u0");
  if(!field_ptr) {
    ;
  }
  else {
    real_data_ptr = (double *)mxGetPr(field_ptr);
  
    total_num_of_elements = mxGetM(field_ptr) * mxGetN(field_ptr);
  
    u0 = mxCalloc(constr+mconstr, sizeof(double));
      
    i = (total_num_of_elements < constr+mconstr) ? total_num_of_elements : constr+mconstr;

    for (c = 0; c < i; c++)
      u0[c] = real_data_ptr[c];
    for (c = i; c < constr+mconstr; c++)
      u0[c] = real_data_ptr[c];
  }
  
  dim = constr;
  
  for(i=0; i<mconstr; i++) {
    dim += msizes[i]*(msizes[i]+1)/2;
  }
  
  if(nlhs > 2) {
    plhs[2] = mxCreateDoubleMatrix(1, dim, mxREAL);
    uoutput = (double *)mxGetPr(plhs[2]);
  }
  
  else {
    uoutput = 0;
  }
  
  if(nlhs > 4) {
    iresults = (int*) mxCalloc(4, sizeof(int));
  }
  
  else {
    iresults = 0;
  }
  
  if(nlhs > 5) {
    plhs[5] = mxCreateDoubleMatrix(1, 5, mxREAL);
    fresults = (double *) mxGetPr(plhs[5]);
  }
  
  else {
    fresults = 0;
  }
  
  pensdp(vars, constr, mconstr, msizes,
    &fX, x_opt, u0, uoutput, fobj, ci,
    bi_dim, bi_idx, bi_val,
    ai_dim, ai_idx, ai_nzs,
    ai_val, ai_col, ai_row,
    ioptions, foptions,
    iresults, fresults, &inform);
  
  if(nlhs > 0) {
    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
    real_data_ptr = mxGetPr(plhs[0]);
    real_data_ptr[0] = fX;
  } 
  
  if(nlhs > 3) {
    plhs[3] = mxCreateDoubleMatrix(1, 1, mxREAL);
    real_data_ptr = mxGetPr(plhs[3]);
    real_data_ptr[0] = (double) inform;
  }
  
  if(nlhs > 4) {
    plhs[4] = mxCreateDoubleMatrix(1, 4, mxREAL);
    real_data_ptr = (double *) mxGetPr(plhs[4]);
    for(i=0; i<4; i++) {
      real_data_ptr[i] = (double) iresults[i];
    }
    mxFree(iresults);
  }
  
  if(constr) { 
    mxFree(bi_idx);
    mxFree(bi_val);
    mxFree(bi_dim);
    mxFree(ci);
  } 
  
  if(mconstr) { 
    mxFree(ai_idx);
    mxFree(ai_val);
    mxFree(ai_dim);
    mxFree(ai_nzs);
    mxFree(ai_row);
    mxFree(ai_col);
    mxFree(msizes);
  }
  
  if(nlhs < 1)
    mxFree(x_opt);
  if(fobj)
    mxFree(fobj);
  if(ioptions)  
    mxFree(ioptions);
  if(foptions)
    mxFree(foptions);
  
  return;
}
/* END */


