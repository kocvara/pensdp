%**************************************************************************
%                mex-command PENSDP 2.2 (Matlab interface)                *
%								                                          *
% Copyright (c) 2003-2011 by M. Kocvara and M. Stingl                     *
% Version 03/02/11                                                        *
%**************************************************************************

function make_pensdpmw64()

    mex -O  pensdpm.c penoutm.c  ../lib/pensdpm64.lib ...
        C:\PROGRA~1\MATLAB\R2023a\extern\lib\win64\microsoft\libmwlapack.lib ...
        C:\PROGRA~1\MATLAB\R2023a\extern\lib\win64\microsoft\libmwblas.lib
